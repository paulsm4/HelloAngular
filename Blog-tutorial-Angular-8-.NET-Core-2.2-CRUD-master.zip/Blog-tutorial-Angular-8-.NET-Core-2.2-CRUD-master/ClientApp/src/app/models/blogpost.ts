export class BlogPost {
  postId?: number;
  creator: string;
  title: string;
  body: string;
  dt: Date;
}
